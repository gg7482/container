EKS Implementation Guide has [moved](eks-implementation-guide.md).
